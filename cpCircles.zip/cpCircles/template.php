<?php
$page->head_js[] = dirname(rawurldecode($page->theme_path)).'/js/js.js';
?>
<!DOCTYPE html>
<html lang="de">
<head>
<meta charset="utf-8"><?php  gpOutput::GetHead(); ?>
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="x-ua-compatible" content="ie=edge">
<link rel="preload" href="<?php echo dirname(rawurldecode($page->theme_path)); ?>/fonts/LatoLatin-Regular.woff2" as="font" type="font/woff2" crossorigin="anonymous">
</head>
<body>
<header>
	<h1>
		<a href="/">
			<?php gpOutput::GetImage('images/ts-logo-o-color.svg', array('alt'=>'Logo')); ?>
		</a>
	</h1>
	<div class="slogan">
		<?php gpOutput::Get('Extra','Header'); ?>
	</div>
	<div class="social">
		<?php gpOutput::Get('Extra','Cir_Header_SocialMedia'); ?>
	</div>
</header>
<div class="hi">
	<?php gpOutput::GetImage('images/header.jpg', array('alt'=>'', 'class'=>'header-img '));	?>
</div>
<div class="nav-mobile">
	<a id="nav-toggle" href="#!"><span></span></a>
</div>
<nav class="nav-collapse" id="toggleMe">
	<?php
	gpOutput::Get('TopTwoMenu');
	?>
</nav>
<article role="main">
	<?php $page->GetContent(); ?>
	<aside>
		<?php gpOutput::Get('Extra','Side_Menu'); ?>
	</aside>
</article>
<footer class="cpCircle">
	<?php gpOutput::GetAllGadgets(); ?>
	<div class="f-col">
		<?php gpOutput::Get('Extra','Cir_Footer_Column_1'); ?>
	</div>
	<div class="f-col">
		<?php gpOutput::Get('Extra','Cir_Footer_Column_2'); ?>
	</div>
	<div class="f-col">
		<?php gpOutput::Get('Extra','Cir_Footer_Column_3'); ?>
	</div>
    <a href="#" id="to-top"><i></i><span>⇧</span></a>
</footer>
	<?php gpOutput::GetAdminLink(); ?>
<link rel="stylesheet" media="print" href='<?php echo rawurldecode($page->theme_path); ?>/print.css'>
</body>
</html>