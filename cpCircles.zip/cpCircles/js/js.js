jQuery(document).ready(function ($) {
    /* Bei Klick Unterpunkte öffnen
    (nur 2 Ebenen)
     *********************************/
    $('#toggleMe ul').addClass('jshide');
    $('#toggleMe ul ul').addClass('jshide');
    $(function() {
        $('#toggleMe ul li > a:not(:only-child)').click(function(e) {
            $(this).siblings('#toggleMe ul ul').toggle();
            $('#toggleMe ul ul').not($(this).siblings()).hide(); // schliessen bei Klick auf andere Seite
            e.preventDefault();
            e.stopPropagation();
        });
        $('html').click(function() {
            $('#toggleMe ul ul').hide(); // schliessen bei Klick irgendwo auf der Seite
        });
    });

    /* Hamburger
     *************/
    var container = document.getElementById('toggleMe');
    var toggle = document.getElementById('nav-toggle');
    toggle.addEventListener('click', function(e) {
        e.preventDefault();
        $(container).find('ul').slideToggle();
        toggle.classList.toggle('active');
        if (!container.classList.contains('active')) {
            container.classList.add('active');
        } else {
            container.classList.remove('active');
        }
    });

    /* Pfeil nach oben
     ******************/
    $(window).scroll(function() {
        if ($(this).scrollTop() < 200) {
            $('#to-top').fadeOut(200);
        } else {
            $('#to-top').fadeIn(800);
        }
    });
    $('#to-top').on('click', function() {
        $('html, body').animate({ scrollTop: 0 }, 'middle');
        return false;
    });
});