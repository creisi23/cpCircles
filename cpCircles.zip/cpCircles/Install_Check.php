<?php
/**
 * Bootstrap 4 - Typesetter CMS theme
 * Installation Check
 */

defined('is_running') or die('Not an entry point...');

/**
 * Install_Check() can be used to check the destination server for required features
 * 	This can be helpful for addons that require PEAR support or extra PHP Extensions
 * 	Install_Check() is called from step1 of the install/upgrade process
 */
function Install_Check(){
	global $dataDir;

	/**
	 * create required Extra Content areas if they don't already exist
	 *
	 */
	//Header Social Media
	if( !\gp\admin\Content\Extra::AreaExists('Cir_Header_SocialMedia') ){
		$file		= $dataDir . '/data/_extra/Cir_Header_SocialMedia/page.php';
		$content	= '<a title="Twitter" class="fa fa-twitter" target="blank" href="https://twitter.com">&zwnj;</a>
		<a title="facebook" class="fa fa-facebook" target="blank" href="https://www.facebook.com">&zwnj;</a>
		<a title="Instagram" class="fa fa-instagram" target="blank" href="https://www.instagram.com">&zwnj;</a>
		<a title="LinkedIn" class="fa fa-linkedin-square" target="blank" href="https://www.linkedin.com">&zwnj;</a>
		<a title="YouTube" class="fa fa-youtube" target="blank" href="https://www.youtube.com">&zwnj;</a>
		<a title="Skype" class="fa fa-skype" target="blank" href="https://www.skype.com">&zwnj;</a>';
		if( \gp\install\Tools::NewExtra($file, $content) ){
			msg('<i class="fa fa-check"></i> The new Extra Content <em>Cir Header SocialMedia</em> was created.');
		}else{
			msg('<i class="fa fa-exclamation-triangle"></i> Warning: ' .
				'The new Extra Content <em>Cir Header SocialMedia</em> could not be created.');
		}
	}
	if( !\gp\admin\Content\Extra::AreaExists('Cir_Footer_Column_1') ){
		$file		= $dataDir . '/data/_extra/Cir_Footer_Column_1/page.php';
		$content	= '<p>Footer Column 1</p>';
		if( \gp\install\Tools::NewExtra($file, $content) ){
			msg('<i class="fa fa-check"></i> The new Extra Content <em>Cir Footer Column 1</em> was created.');
		}else{
			msg('<i class="fa fa-exclamation-triangle"></i> Warning: ' .
				'The new Extra Content <em>Cir Header Footer Column 1</em> could not be created.');
		}
	}
	if( !\gp\admin\Content\Extra::AreaExists('Cir_Footer_Column_2') ){
		$file		= $dataDir . '/data/_extra/Cir_Footer_Column_2/page.php';
		$content	= '<p>Footer Column 1</p>';
		if( \gp\install\Tools::NewExtra($file, $content) ){
			msg('<i class="fa fa-check"></i> The new Extra Content <em>Cir Footer Column 2</em> was created.');
		}else{
			msg('<i class="fa fa-exclamation-triangle"></i> Warning: ' .
				'The new Extra Content <em>Cir Header Footer Column 2</em> could not be created.');
		}

	}
	if( !\gp\admin\Content\Extra::AreaExists('Cir_Footer_Column_3') ){
		$file		= $dataDir . '/data/_extra/Cir_Footer_Column_3/page.php';
		$content	= '<p>Footer Column 1</p>';
		if( \gp\install\Tools::NewExtra($file, $content) ){
			msg('<i class="fa fa-check"></i> The new Extra Content <em>Cir Footer Column 3</em> was created.');
		}else{
			msg('<i class="fa fa-exclamation-triangle"></i> Warning: ' .
				'The new Extra Content <em>Cir Header Footer Column 3</em> could not be created.');
		}

	}
	return true;
}
